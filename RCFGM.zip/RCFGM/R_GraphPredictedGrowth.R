# latent means
means <- c(9.238,8.983,8.978,8.892,8.698,8.794,8.565)
SEs <- c(0.139,0.181,0.180,0.196,0.190,0.195,0.186)
years <- c(1971,1985,1988,1991,1994,1997,2000)

meansSEm <- means - SEs
meansSEp <- means + SEs
meansSEm
meansSEp


# predicted curve
plot(x = c(0,29), y = c(5, 10), type = "n", xlab="Year of assessment", ylab="Mean couples' negative sentiment", axes = FALSE)
box(lty = c(0:29,4:10)) #- to make it look "as usual"
lines(x = c(-1.2,-1.2), y = c(0,10),col = "black")
lines(x = c(-1.2,29), y = c(4.8,4.8),col = "black")

curve(9.281 - 0.018*time, from=0, to=20, add=T, lwd=1.2, xname = "time", col = "black")
curve(9.281 - 0.1 - 0.018*time, from=23, to=29, add=T, lwd=1.2, xname = "time", col = "black")

y00 <- 9.281;y00
y20 <- 9.281 - 0.018*20;y20
y23 <- 9.281 -0.1 - 0.018*23;y23
y29 <- 9.281 -0.1 - 0.018*29;y29
lines(c(20,23),c(y20,y23),lwd=1.2, col = "black")
# lines(x = c(0,0), y = c(0,y00),col = "darkgrey")
lines(x = c(20,20), y = c(0,y20),col = "darkgrey")
lines(x = c(23,23), y = c(0,y23),col = "darkgrey")
# lines(x = c(29,29), y = c(0,y29),col = "darkgrey")

library(Hmisc)
errbar(x=c(0,14,17,20,23,26,29),y=means,yplus=meansSEp,yminus=meansSEm, add=TRUE)

# y and x axis, 
axis(2, 5:10)
axis(1, at=c(0,14,17,20,23,26,29),labels=c(1971,1985,1988,1991,1994,1997,2000), las=2)








# German
plot(x = c(0,29), y = c(5, 10), type = "n", xlab="Erhebungsjahr", ylab="Beziehungsprobleme", main = "Ver�nderung der Beziehungsprobleme",axes = FALSE)
box(lty = c(0:29,4:10)) #- to make it look "as usual"
lines(x = c(-1.2,-1.2), y = c(0,10),col = "black")
lines(x = c(-1.2,29), y = c(4.8,4.8),col = "black")

curve(9.281 - 0.018*time, from=0, to=20, add=T, lwd=2, xname = "time", col = "darkblue")
curve(9.281 - 0.1 - 0.018*time, from=23, to=29, add=T, lwd=2, xname = "time", col = "darkblue")

y00 <- 9.281;y00
y20 <- 9.281 - 0.018*20;y20
y23 <- 9.281 -0.1 - 0.018*23;y23
y29 <- 9.281 -0.1 - 0.018*29;y29
lines(c(20,23),c(y20,y23),lwd=2, col = "darkblue")
# lines(x = c(0,0), y = c(0,y00),col = "darkgrey")
lines(x = c(20,20), y = c(0,y20),col = "darkgrey")
lines(x = c(23,23), y = c(0,y23),col = "darkgrey")
# lines(x = c(29,29), y = c(0,y29),col = "darkgrey")

library(Hmisc)
errbar(x=c(0,14,17,20,23,26,29),y=means,yplus=meansSEp,yminus=meansSEm, add=T)

# y and x axis, 
axis(2, 5:10)
axis(1, at=c(0,14,17,20,23,26,29),labels=c(1971,1985,1988,1991,1994,1997,2000), las=2)




plot(c(0,29), c(5, 10), type = "n", cex.lab = 1.5, xlab="", ylab="Beziehungsprobleme", main = "Ver�nderung der Beziehungsprobleme", axes = F, col = "blue")
box() #- to make it look "as usual"

curve(9.281 - 0.018*time, from=0, to=20, add=T, lwd=2, xname = "time", col = "darkblue")
curve(9.281 - 0.1 - 0.018*time, from=23, to=29, add=T, lwd=2, xname = "time", col = "darkblue")

y23 <- 9.281 -0.1 - 0.018*23
y20 <- 9.281 - 0.018*20;y20
lines(c(20,23),c(y20,y23),lwd=2, col = "darkblue")
lines(x = c(20,20), y = c(0,y20),col = "darkgrey")
lines(x = c(23,23), y = c(0,y23),col = "darkgrey")
axis(2, 5:10,cex.axis = 1.2)
axis(1, at=c(0,14,17,20,23,26,29),labels=c(1971,1985,1988,1991,1994,1997,2000), las=2, cex.axis = 1.2)

xlab(4,3,"Jahre")
mtext("Jahre",side = 1,line = 4, cex = 1.5)