#######################################################
#####      Date created    July 19, 2012          #####
#####      Date modified   July 2, 2013           #####
#######################################################

###    R E S T R U C T U R I N G    D Y A D I C    O R G A N I Z E D    D A T A  
###    T O    I N D I V I D U A L    O R G A N I Z E D    D A T A    F O R    M S E M

# Example data
dID    <- rep(1:8)
Wh     <- c(5,2,6,4,3,NA,1,8)
Xh     <- c(9,8,3,6,6,7,2,4)
Yh     <- c(4,2,2,4,6,7,5,9)
Zh     <- c(3,3,7,7,5,5,9,9)
Ww     <- c(3,1,4,7,2,3,4,6)
Xw     <- c(4,8,3,6,6,7,2,4)
Yw     <- c(4,8,4,1,NA,9,0,2)
Zw     <- c(6,NA,9,0,3,1,3,2)
ddat  <- data.frame(cbind(dID,Wh,Xh,Yh,Zh,Ww,Xw,Yw,Zw)); ddat  # dyadic organized data



dyad2ind <- function(datm,id,nameA,nameB,catname="nameAnameB",Sep = "") {
    vc <- NULL; vi <- 0
    nd <- nrow(datm)                                      # number of dyads
    nameASep <- paste(Sep,nameA,sep = "")                 # name of member A including the Sep
    nameBSep <- paste(Sep,nameB,sep = "")
    names(datm) <- sub(nameASep,nameA,names(datm))        # replace 
    names(datm) <- sub(nameBSep,nameB,names(datm))
    nlA <- nchar(nameA)       # length of nameA
    nlB <- nchar(nameB)           
    if(nlA >= nlB) {
           vnll <- nlA        # length of longer class name
           cname <- nameA     # class name
           vnls <- nlB        # length of shorter class name
    } else {
           vnll <- nlB        # length of longer class name
           cname <- nameB     # class name
           vnls <- nlA        # length of shorter class name
    }
    vecname1 <- rep(cname,nd)
    ifelse(cname == nameA, vecname2 <- rep(nameB,nd), vecname2 <- rep(nameA,nd))
    subdat1 <- cbind(datm[id],vecname1)
    subdat2 <- cbind(datm[id],vecname2)
    datm <- datm[names(datm) != id]      # excludes id variables
    nv <- ncol(datm)                     # number of variables
    v1i <- v2i <- 2
    for (i in 1:nv) {
          vi <- vi + 1
          classnamei <- substr(names(datm[vi]),nchar(names(datm[vi]))-vnll+1,nchar(names(datm[vi])))
          if(classnamei == cname){
               v1i <- v1i+1
               varnamei <- substr(names(datm[vi]),1,nchar(names(datm[vi]))-vnll) # variable name
               subdat1 <- cbind(subdat1,datm[vi])
               names(subdat1)[v1i] <- varnamei
          } else {
               v2i <- v2i+1
               varnamei <- substr(names(datm[vi]),1,nchar(names(datm[vi]))-vnls) # variable name
               subdat2 <- cbind(subdat2,datm[vi])
               names(subdat2)[v2i] <- varnamei
          }
    }
    names(subdat1)[2] <- catname
    names(subdat2)[2] <- catname
    datind <- rbind(subdat1,subdat2)
}

datMV <- dyad2ind(ddat,"dID","h","w",catname="Gender")
datMV